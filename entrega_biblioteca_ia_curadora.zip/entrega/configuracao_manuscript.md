# Configuração no Manuscript.ink

Este documento contém as instruções para configurar o MCP "Biblioteca IA Curadora - Neuroacessível" no [manuscript.ink](https://manuscript.ink).

## Passo 1: Criar uma nova conta ou fazer login

1. Acesse [manuscript.ink](https://manuscript.ink)
2. Crie uma nova conta ou faça login com sua conta existente

## Passo 2: Criar um novo MCP

1. No dashboard, clique em "Criar novo MCP" ou botão equivalente
2. Dê um nome ao seu MCP: "Biblioteca IA Curadora - Neuroacessível"

## Passo 3: Configurar o prompt YAML

1. Na seção de configuração do MCP, cole o seguinte código YAML:

```yaml
title: Biblioteca IA Curadora - Neuroacessível

description: >
  Este agente sugere ferramentas digitais com base em perfis diversos, como educadores,
  desenvolvedores ou criadores, com foco em IA, automação, acessibilidade e neuroeducação.

inputs:
  - label: Qual seu perfil ou desafio atual?
    name: perfil
    type: text
    placeholder: Ex: "sou professora da rede pública", "sou dev autônomo", "quero adaptar materiais para alunos com autismo"
    required: true

steps:
  - name: recomendar_ferramentas
    type: llm
    prompt: |
      A partir do seguinte perfil de usuário: {{ perfil }},
      sugira uma lista de 3 a 5 ferramentas tecnológicas que possam ajudar essa pessoa em seu contexto.

      Use a base de dados fictícia abaixo para escolher as ferramentas:
      
      - Genspark: Geração de conteúdo educacional com IA
      - n8n: Automatização de tarefas via fluxos visuais
      - Zapier: Automação low-code com integração de apps
      - Hugging Face Spaces: Criação e deploy de agentes de IA
      - Perplexity AI: Pesquisa baseada em linguagem natural
      - Make.com: Automações visuais para produtividade
      - Manuscript: Criação de agentes de IA interativos
      - Tactiq: Transcrição automática de reuniões e vídeos
      - Gamma.app: Criação de apresentações com IA
      - Teachable Machine: Machine Learning com exemplos visuais
      - Canva: Design acessível e colaborativo
      - ChatGPT: Assistente para escrita, código, planejamento e ideias

      Para cada ferramenta, inclua:
      - Nome da ferramenta
      - Por que ela é útil para esse perfil
      - Exemplo prático de como essa pessoa pode usá-la
      - Link (se possível)

      A resposta deve ser clara, acessível e com tom amigável, como uma curadoria feita por uma mentora digital.

output:
  type: markdown
```

## Passo 4: Personalizar a aparência (opcional)

1. Na seção de personalização, você pode:
   - Escolher cores que reflitam acessibilidade (alto contraste)
   - Adicionar um logo relacionado à educação inclusiva
   - Personalizar o estilo visual para ser amigável e acolhedor

## Passo 5: Testar o MCP

1. Clique em "Testar" ou botão equivalente
2. Insira um perfil de teste, como "sou professora da rede pública que trabalha com alunos neurodivergentes"
3. Verifique se a resposta segue o formato esperado, com recomendações personalizadas

## Passo 6: Publicar o MCP

1. Quando estiver satisfeito com os resultados, clique em "Publicar" ou botão equivalente
2. Escolha as configurações de privacidade:
   - Público: qualquer pessoa pode acessar
   - Privado: apenas pessoas com o link podem acessar
   - Restrito: apenas usuários específicos podem acessar

## Passo 7: Compartilhar o MCP

1. Após a publicação, você receberá um link para compartilhar
2. Compartilhe este link com educadores, desenvolvedores e outros profissionais que possam se beneficiar das recomendações de ferramentas

## Dicas adicionais

- **Atualize regularmente a base de dados de ferramentas** para manter as recomendações relevantes
- **Colete feedback dos usuários** para melhorar as descrições e exemplos
- **Considere adicionar categorias** se a lista de ferramentas crescer significativamente
- **Monitore o uso** para entender quais perfis são mais comuns e adaptar as recomendações

## Integração com o frontend React (opcional)

Se desejar integrar o frontend React desenvolvido com o manuscript.ink:

1. No manuscript.ink, procure por opções de "API" ou "Integração"
2. Obtenha uma chave de API ou endpoint para seu MCP
3. No código React, substitua a simulação atual por chamadas reais à API do manuscript.ink
4. Implante o frontend em um serviço de hospedagem como Vercel, Netlify ou GitHub Pages
