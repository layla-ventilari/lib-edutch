import React, { useState } from 'react';
import styled from 'styled-components';
import Header from './components/Header';
import ProfileForm from './components/ProfileForm';
import Recommendations from './components/Recommendations';

const AppContainer = styled.div`
  min-height: 100vh;
  background-color: #f8f9fa;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
`;

const Footer = styled.footer`
  text-align: center;
  padding: 2rem;
  color: #666;
  font-size: 0.9rem;
`;

function App() {
  const [isLoading, setIsLoading] = useState(false);
  const [recommendations, setRecommendations] = useState<string | null>(null);

  // Simulação da chamada à API do MCP
  const handleSubmit = (profile: string) => {
    setIsLoading(true);
    
    // Simulando o tempo de resposta da API
    setTimeout(() => {
      // Exemplo de resposta baseado no exemplo_resposta.md
      const exampleResponse = `# Ferramentas Recomendadas para Você

Com base no seu perfil: **"${profile}"**, selecionei estas ferramentas que podem transformar sua experiência:

## Genspark

**Por que é útil para você:** O Genspark permite criar materiais educacionais personalizados com IA, adaptando conteúdos para diferentes estilos de aprendizagem e necessidades sensoriais.

**Exemplo prático:** Você pode usar o Genspark para transformar um texto complexo em uma explicação visual com analogias concretas e linguagem simplificada, ideal para diferentes perfis de processamento.

**Link:** [genspark.ai](https://genspark.ai)

## Teachable Machine

**Por que é útil para você:** Esta ferramenta da Google permite criar modelos de reconhecimento personalizados sem programação, possibilitando desenvolver recursos de acessibilidade adaptados às necessidades específicas.

**Exemplo prático:** Você pode criar um sistema que reconhece padrões específicos, transformando-os em comandos ou respostas no computador durante atividades interativas.

**Link:** [teachablemachine.withgoogle.com](https://teachablemachine.withgoogle.com)

## Gamma.app

**Por que é útil para você:** O Gamma permite criar apresentações visualmente atraentes e interativas com ajuda de IA, facilitando a criação de materiais que capturam a atenção de diferentes perfis.

**Exemplo prático:** Você pode criar uma apresentação com elementos visuais marcantes, transições suaves e estrutura previsível, reduzindo a sobrecarga sensorial enquanto mantém o engajamento.

**Link:** [gamma.app](https://gamma.app)

---

Espero que estas ferramentas ajudem em seu contexto! Se precisar de sugestões mais específicas, estou à disposição.`;
      
      setRecommendations(exampleResponse);
      setIsLoading(false);
    }, 1500);
  };

  return (
    <AppContainer>
      <Header />
      <ProfileForm onSubmit={handleSubmit} isLoading={isLoading} />
      <Recommendations markdown={recommendations} />
      <Footer>
        Biblioteca IA Curadora - Neuroacessível © {new Date().getFullYear()}
      </Footer>
    </AppContainer>
  );
}

export default App;
