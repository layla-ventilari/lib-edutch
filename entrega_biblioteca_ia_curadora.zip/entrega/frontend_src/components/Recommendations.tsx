import React from 'react';
import styled from 'styled-components';
import ReactMarkdown from 'react-markdown';

const ResultsContainer = styled.div`
  max-width: 800px;
  margin: 2rem auto;
  padding: 0 1rem;
`;

const ToolCard = styled.div`
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  border-left: 5px solid #6e8efb;
  transition: transform 0.2s;

  &:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
  }
`;

const ToolName = styled.h2`
  color: #333;
  margin-top: 0;
  margin-bottom: 0.5rem;
  font-size: 1.5rem;
`;

const ToolDescription = styled.div`
  color: #444;
  line-height: 1.6;
  
  p {
    margin-bottom: 1rem;
  }
  
  strong {
    color: #333;
  }
  
  a {
    color: #6e8efb;
    text-decoration: none;
    font-weight: 600;
    
    &:hover {
      text-decoration: underline;
    }
  }
`;

const NoResults = styled.div`
  text-align: center;
  padding: 3rem;
  color: #666;
`;

interface ToolRecommendation {
  name: string;
  why: string;
  example: string;
  link: string;
}

interface RecommendationsProps {
  markdown: string | null;
}

const Recommendations: React.FC<RecommendationsProps> = ({ markdown }) => {
  if (!markdown) {
    return (
      <ResultsContainer>
        <NoResults>
          <h2>Insira seu perfil para receber recomendações personalizadas</h2>
          <p>Descreva seu contexto profissional ou desafio específico para obter as melhores sugestões de ferramentas.</p>
        </NoResults>
      </ResultsContainer>
    );
  }

  return (
    <ResultsContainer>
      <ReactMarkdown>{markdown}</ReactMarkdown>
    </ResultsContainer>
  );
};

export default Recommendations;
