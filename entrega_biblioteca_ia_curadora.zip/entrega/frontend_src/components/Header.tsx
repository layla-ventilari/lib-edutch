import React from 'react';
import styled from 'styled-components';

const HeaderContainer = styled.header`
  background: linear-gradient(135deg, #6e8efb 0%, #a777e3 100%);
  color: white;
  padding: 2rem 1rem;
  text-align: center;
  border-radius: 0 0 10px 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
`;

const Title = styled.h1`
  font-size: 2rem;
  margin-bottom: 0.5rem;
  font-weight: 700;
`;

const Subtitle = styled.p`
  font-size: 1.1rem;
  opacity: 0.9;
  max-width: 600px;
  margin: 0 auto;
`;

const Header: React.FC = () => {
  return (
    <HeaderContainer>
      <Title>Biblioteca IA Curadora</Title>
      <Subtitle>
        Ferramentas digitais personalizadas para educação, criação e desenvolvimento com foco em acessibilidade e neuroeducação
      </Subtitle>
    </HeaderContainer>
  );
};

export default Header;
