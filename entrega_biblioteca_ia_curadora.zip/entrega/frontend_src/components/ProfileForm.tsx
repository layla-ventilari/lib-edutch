import React, { useState } from 'react';
import styled from 'styled-components';

const FormContainer = styled.div`
  max-width: 600px;
  margin: 2rem auto;
  padding: 1.5rem;
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
`;

const StyledForm = styled.form`
  display: flex;
  flex-direction: column;
`;

const Label = styled.label`
  font-size: 1.1rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: #333;
`;

const Input = styled.input`
  padding: 0.8rem;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  font-size: 1rem;
  margin-bottom: 1.5rem;
  transition: border-color 0.3s;

  &:focus {
    border-color: #6e8efb;
    outline: none;
  }
`;

const SubmitButton = styled.button`
  background: linear-gradient(135deg, #6e8efb 0%, #a777e3 100%);
  color: white;
  border: none;
  padding: 0.8rem 1.5rem;
  font-size: 1rem;
  font-weight: 600;
  border-radius: 8px;
  cursor: pointer;
  transition: transform 0.2s, box-shadow 0.2s;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  }

  &:disabled {
    background: #cccccc;
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
  }
`;

const Hint = styled.p`
  color: #666;
  font-size: 0.9rem;
  margin-top: -1rem;
  margin-bottom: 1.5rem;
`;

interface ProfileFormProps {
  onSubmit: (profile: string) => void;
  isLoading: boolean;
}

const ProfileForm: React.FC<ProfileFormProps> = ({ onSubmit, isLoading }) => {
  const [profile, setProfile] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (profile.trim()) {
      onSubmit(profile);
    }
  };

  return (
    <FormContainer>
      <StyledForm onSubmit={handleSubmit}>
        <Label htmlFor="profile">Qual seu perfil ou desafio atual?</Label>
        <Input
          id="profile"
          type="text"
          value={profile}
          onChange={(e) => setProfile(e.target.value)}
          placeholder="Ex: sou professora da rede pública, sou dev autônomo, quero adaptar materiais para alunos com autismo"
          required
          aria-required="true"
        />
        <Hint>
          Descreva seu contexto profissional ou desafio específico para receber recomendações personalizadas.
        </Hint>
        <SubmitButton type="submit" disabled={!profile.trim() || isLoading}>
          {isLoading ? 'Buscando recomendações...' : 'Receber recomendações'}
        </SubmitButton>
      </StyledForm>
    </FormContainer>
  );
};

export default ProfileForm;
