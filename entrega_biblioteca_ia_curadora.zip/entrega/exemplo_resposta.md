# Ferramentas Recomendadas para Você

Com base no seu perfil: **"sou professora da rede pública que trabalha com alunos neurodivergentes"**, selecionei estas ferramentas que podem transformar sua experiência em sala de aula:

## Genspark

**Por que é útil para você:** O Genspark permite criar materiais educacionais personalizados com IA, adaptando conteúdos para diferentes estilos de aprendizagem e necessidades sensoriais dos seus alunos neurodivergentes.

**Exemplo prático:** Você pode usar o Genspark para transformar um texto complexo sobre fotossíntese em uma explicação visual com analogias concretas e linguagem simplificada, ideal para alunos com processamento sensorial diferenciado.

**Link:** [genspark.ai](https://genspark.ai)

## Teachable Machine

**Por que é útil para você:** Esta ferramenta da Google permite criar modelos de reconhecimento personalizados sem programação, possibilitando desenvolver recursos de acessibilidade adaptados às necessidades específicas da sua sala.

**Exemplo prático:** Você pode criar um sistema que reconhece gestos específicos de comunicação não-verbal dos seus alunos com autismo, transformando-os em comandos ou respostas no computador durante atividades interativas.

**Link:** [teachablemachine.withgoogle.com](https://teachablemachine.withgoogle.com)

## Gamma.app

**Por que é útil para você:** O Gamma permite criar apresentações visualmente atraentes e interativas com ajuda de IA, facilitando a criação de materiais que capturam a atenção de alunos com diferentes perfis de processamento sensorial.

**Exemplo prático:** Você pode criar uma apresentação sobre história do Brasil com elementos visuais marcantes, transições suaves e estrutura previsível, reduzindo a sobrecarga sensorial enquanto mantém o engajamento dos alunos.

**Link:** [gamma.app](https://gamma.app)

## Tactiq

**Por que é útil para você:** Esta ferramenta transcreve automaticamente reuniões e vídeos, permitindo que você ofereça conteúdo em múltiplos formatos para atender diferentes necessidades de processamento.

**Exemplo prático:** Você pode gravar suas aulas e usar o Tactiq para gerar transcrições precisas, oferecendo aos alunos que processam melhor informações escritas uma alternativa ao conteúdo verbal, além de facilitar revisões e estudos posteriores.

**Link:** [tactiq.io](https://tactiq.io)

---

Espero que estas ferramentas ajudem a tornar sua sala de aula mais inclusiva e adaptada às necessidades dos seus alunos! Se precisar de sugestões mais específicas ou tiver dúvidas sobre como implementar alguma dessas ferramentas, estou à disposição.
